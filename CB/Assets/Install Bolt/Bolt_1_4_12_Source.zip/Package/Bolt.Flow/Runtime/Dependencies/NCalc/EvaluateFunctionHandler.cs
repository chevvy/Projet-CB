﻿namespace Bolt.Dependencies.NCalc
{
	public delegate void EvaluateFunctionHandler(Flow flow, string name, FunctionArgs args);
}